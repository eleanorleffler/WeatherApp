﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Threading.Tasks;
using Windows.Data.Json;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace WeatherApp
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        #region Private Members

        private ObservableCollection<string> favoriteAirports;
        private ObservableCollection<string> previouslySearched;

        #endregion

        #region Constructors

        public MainPage()
        {
            this.InitializeComponent();

            favoriteAirports = new ObservableCollection<string>(){ "KPWM", "KAUS"};
            previouslySearched = new ObservableCollection<string>();

            updateFavoritesListView();
        }

        #endregion

        #region Search AutoSuggest Methods

        private void searchAutoSuggestBox_TextChanged(AutoSuggestBox sender, AutoSuggestBoxTextChangedEventArgs args)
        {
            sender.ItemsSource = previouslySearched;
        }

        private void searchAutoSuggestBox_SuggestionChosen(AutoSuggestBox sender, AutoSuggestBoxSuggestionChosenEventArgs args)
        {
            string aiportIdentifier = args.SelectedItem.ToString();

            searchForAirportIdentifier(sender, aiportIdentifier);
        }

        private void searchAutoSuggestBox_QuerySubmitted(AutoSuggestBox sender, AutoSuggestBoxQuerySubmittedEventArgs args)
        {
            string aiportIdentifier;
            if (args.ChosenSuggestion != null)
            {
                aiportIdentifier = args.ChosenSuggestion.ToString();
            }
            else
            {
                aiportIdentifier = args.QueryText;
            }

            searchForAirportIdentifier(sender, aiportIdentifier);
        }

        private async void searchForAirportIdentifier(AutoSuggestBox sender, string aiportIdentifier)
        {
            if (!string.IsNullOrWhiteSpace(aiportIdentifier))
            {
                aiportIdentifier = aiportIdentifier.ToUpper();
                string httpResponseBody = await WeatherDataHelper.GetWeatherHttpResponseBody(aiportIdentifier);

                if (!(httpResponseBody.Contains("Error")))
                {
                    if (!previouslySearched.Contains(aiportIdentifier))
                    {
                        previouslySearched.Add(aiportIdentifier);
                        sender.ItemsSource = previouslySearched;
                    }
                    bool isFavorite = favoriteAirports.Contains(aiportIdentifier);
                    DetailsPage detailsPage = new DetailsPage(this, aiportIdentifier, isFavorite);
                    Frame.Content = detailsPage;
                }
                else
                {
                    ObservableCollection<string> notFound = new ObservableCollection<string>() { "No Results Found" };
                    sender.ItemsSource = notFound;
                }
            }
        }

        #endregion

        #region Favorites ListView Methods

        private void updateFavoritesListView()
        {
            favoritesListView.ItemsSource = favoriteAirports;
        }

        private void favoritesListView_DoubleTapped(object sender, DoubleTappedRoutedEventArgs e)
        {
            string airportIndicator = favoritesListView.SelectedItem as string;
            DetailsPage detailsPage = new DetailsPage(this, airportIndicator, true);
            Frame.Content = detailsPage;
        }

        public void AddFavorite(string airportIndicator)
        {
            favoriteAirports.Add(airportIndicator);
            updateFavoritesListView();
        }

        public void RemoveFavorite(string airportIndicator)
        {
            favoriteAirports.Remove(airportIndicator);
            updateFavoritesListView();
        }

        #endregion

    }
}
