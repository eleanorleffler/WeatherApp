﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.Data.Json;

namespace WeatherApp
{
    public class WeatherReport
    {

        #region Constructors

        public WeatherReport()
        {

        }

        public WeatherReport(JsonObject jsonObject)
        {
            try
            {
                JsonObject report = jsonObject.GetNamedObject("report");
                JsonObject conditions = report.GetNamedObject("conditions");

                currentConditions = new WeatherConditions(conditions);
            }
            catch
            { 
            
            }
        }

        #endregion

        #region Public Properties

        public WeatherConditions CurrentConditions
        {
            get { return currentConditions; }
        }

        #endregion

        #region Public Methods

        #endregion

        #region Private Members

        private WeatherConditions currentConditions;

        // Forecast
        //private DateTime dateIssuedForecast;
        //private DateTime periodStart;
        //private DateTime periodStop;

        //private List<WeatherConditions> forecastConditions;
        
        #endregion

    }
}
