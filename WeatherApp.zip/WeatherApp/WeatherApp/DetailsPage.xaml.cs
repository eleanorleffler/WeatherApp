﻿using Windows.Data.Json;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace WeatherApp
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class DetailsPage : Page
    {
        #region Private Members

        private MainPage mainPage;
        private string airportIndicator;
        private bool isFavorite;

        #endregion

        #region Constructors

        public DetailsPage(MainPage mainPage, string airportIndicator, bool isFavorite)
        {
            this.InitializeComponent();

            this.mainPage = mainPage;
            this.airportIndicator = airportIndicator;
            this.isFavorite = isFavorite;

            aiportIndicatorTextBlock.Text = airportIndicator;
            favoriteButton.IsChecked = isFavorite;

            loadWeatherData(airportIndicator);
        }

        #endregion

        #region Button Methods

        private void backButton_Click(object sender, RoutedEventArgs e)
        {
            // Update Favorites if Location's favorite status changed
            if (isFavorite != favoriteButton.IsChecked)
            {
                if ((bool)favoriteButton.IsChecked)
                {
                    mainPage.AddFavorite(airportIndicator);
                }
                else
                {
                    mainPage.RemoveFavorite(airportIndicator);
                }
            }

            mainPage.Frame.Content = mainPage;
        }

        private void refreshButton_Click(object sender, RoutedEventArgs e)
        {
            loadWeatherData(airportIndicator);
        }

        #endregion

        #region Weather Data Methods

        private async void loadWeatherData(string airportIdentifier)
        {
            string httpResponseBody = await WeatherDataHelper.GetWeatherHttpResponseBody(airportIdentifier);

            JsonObject jsonObject = JsonObject.Parse(httpResponseBody);

            WeatherReport weatherReport = new WeatherReport(jsonObject);

            DetailsConditionsPage detailsConditionsPage = new DetailsConditionsPage(weatherReport.CurrentConditions);
            conditionsPivotItem.Content = detailsConditionsPage;

            // needs error checking here

            DetailsForecastPage detailsForecastPage = new DetailsForecastPage();
            forecastPivotItem.Content = detailsForecastPage;
        }

        #endregion

    }
}
