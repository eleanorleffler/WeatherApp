﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.Data.Json;

namespace WeatherApp
{
    public class WeatherConditions
    {

        #region Constructors

        public WeatherConditions()
        {

        }

        public WeatherConditions(JsonObject jsonObject)
        {
            dateIssued = jsonObject.GetNamedString("dateIssued");
            tempC = jsonObject.GetNamedNumber("tempC");
            dewpointC = jsonObject.GetNamedNumber("dewpointC");
            pressureHg = jsonObject.GetNamedNumber("pressureHg");
            densityAltitudeFt = jsonObject.GetNamedNumber("densityAltitudeFt");
            relativeHumidity = jsonObject.GetNamedNumber("relativeHumidity");
        }

        #endregion

        #region Public Properties

        public string DateIssued
        {
            get { return dateIssued; }
        }

        public double TempC
        {
            get { return tempC; }
        }

        public double DewpointC
        {
            get { return dewpointC; }
        }

        public double PressureHg
        {
            get { return pressureHg; }
        }

        public double DensityAltitudeFt
        {
            get { return densityAltitudeFt; }
        }

        public double RelativeHumidity
        {
            get { return relativeHumidity; }
        }

        #endregion

        #region Public Methods

        #endregion

        #region Private Members

        private string dateIssued;

        private double tempC;
        private double dewpointC;
        private double pressureHg;
        private double densityAltitudeFt;
        private double relativeHumidity;
        //private string visibility;

        //private string cloudLayers;
        //private string wind;

        #endregion

    }
}
